var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var FarmSchema = new Schema({
  farmname: {type: String,},
  address: {type: String},
  farmid: {type: String}
});

var Farm = mongoose.model('Farm',FarmSchema);
module.exports = Farm;
