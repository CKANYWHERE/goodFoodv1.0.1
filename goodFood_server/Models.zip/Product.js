var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ProductSchema = new Schema({
  productname:{type: String},
  description:{type: String},
  productorder: String,
  productorgin: String,
  productcost: String,
  imgpath: String
});

var Product = mongoose.model('Product',ProductSchema);
module.exports = Product;
